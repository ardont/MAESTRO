"""
qdrant_indexer.py — Модуль работы с векторной базой Qdrant.

Qdrant — это СПЕЦИАЛЬНАЯ БД для векторов. Отличия от обычной БД:
  - Обычная БД (PostgreSQL): SELECT WHERE name = 'закупка'  → точное совпадение
  - Qdrant: дай 5 ближайших векторов к [0.12, -0.34, ...]     → семантический поиск

Этот модуль отвечает за:
  1. Подключение к Qdrant (сервер или локальный файл)
  2. Создание коллекции с нужной размерностью (1024)
  3. Загрузку чанков и их векторов в базу
"""

import os
import time
from qdrant_client import QdrantClient           # Официальный Python-клиент Qdrant
from qdrant_client.http import models             # Типы данных Qdrant (VectorParams, PointStruct и пр.)
from .config import (
    COLLECTION_NAME, EMBEDDING_DIM, QDRANT_HOST, QDRANT_PORT, QDRANT_STORAGE_DIR
)

# Кэшированный экземпляр клиента (аналог Singleton)
_cached_qdrant_client = None


def get_qdrant_client() -> QdrantClient:
    """
    Возвращает клиент Qdrant с автоматическим fallback и кэшированием.

    Стратегия подключения (с приоритетом):
      1. Локальный сервер Qdrant на localhost:6333
         (запускается отдельно: docker run -p 6333:6333 qdrant/qdrant)
      2. Встроенное локальное хранилище (./qdrant_storage)
         (не требует отдельного процесса, работает через файлы)

    Кэширование: клиент создаётся один раз и переиспользуется.
    """
    global _cached_qdrant_client
    if _cached_qdrant_client is not None:
        return _cached_qdrant_client

    try:
        # Попытка 1: подключиться к Qdrant-серверу (timeout=2сек)
        client = QdrantClient(host=QDRANT_HOST, port=QDRANT_PORT, timeout=2.0)
        client.get_collections()  # Проверка: если сервер не отвечает — выбросится исключение
        print(f"[QDRANT] Connected to Qdrant server at {QDRANT_HOST}:{QDRANT_PORT}")
        _cached_qdrant_client = client
        return client
    except Exception:
        # Попытка 2: сервер недоступен → используем локальное файловое хранилище
        print(f"[QDRANT] Server not found, using embedded local storage: {QDRANT_STORAGE_DIR}")
        _cached_qdrant_client = QdrantClient(path=str(QDRANT_STORAGE_DIR))
        return _cached_qdrant_client

def init_collection(client: QdrantClient, recreate: bool = True):
    """
    Создаёт (или пересоздаёт) коллекцию в Qdrant.

    Коллекция — аналог таблицы в SQL. Хранит:
      - Вектор (1024 числа) — семантическое представление чанка
      - Payload (метаданные) — title, url, category, text, images

    Также создаёт индексы по полям category и doc_type для быстрой фильтрации.

    Аргументы:
      client   — экземпляр QdrantClient
      recreate — если True, удаляет старую коллекцию и создаёт новую
    """
    if recreate:
        # Удаляем старую и создаём новую коллекцию с нужными параметрами:
        #   size=1024  — размерность вектора (должна совпадать с EMBEDDING_DIM)
        #   COSINE    — метрика близости (косинусное сходство, 1.0 = идентичны)
        client.recreate_collection(
            collection_name=COLLECTION_NAME,
            vectors_config=models.VectorParams(
                size=EMBEDDING_DIM,
                distance=models.Distance.COSINE,
            ),
            sparse_vectors_config={
                "bm25": models.SparseVectorParams(
                    modifier=models.Modifier.IDF
                )
            }
        )
        print(f"[QDRANT] Collection '{COLLECTION_NAME}' created/recreated (Dense + BM25).")

        # Создаём payload-индексы — аналог CREATE INDEX в SQL.
        # Это позволяет быстро фильтровать чанки по категории
        # (например, искать только по категории "44fz" или "ecp_mchd")
        try:
            client.create_payload_index(
                collection_name=COLLECTION_NAME,
                field_name="category",
                field_schema=models.PayloadSchemaType.KEYWORD  # Точное совпадение строк
            )
            client.create_payload_index(
                collection_name=COLLECTION_NAME,
                field_name="doc_type",
                field_schema=models.PayloadSchemaType.KEYWORD
            )
            client.create_payload_index(
                collection_name=COLLECTION_NAME,
                field_name="doc_id",
                field_schema=models.PayloadSchemaType.KEYWORD
            )
            print("[QDRANT] Payload indexes created (category, doc_type, doc_id).")
        except Exception as e:
            print(f"[QDRANT] Note on payload index creation: {e}")

def upsert_chunks_batch(client: QdrantClient, chunks: list, embeddings: list, sparse_embeddings: list, batch_size: int = 100):
    """
    Загрузка чанков и их векторов в Qdrant батчами (Hybrid Search: Dense + Sparse).
    """
    total = len(chunks)

    for i in range(0, total, batch_size):
        batch_chunks = chunks[i:i + batch_size]
        batch_vectors = embeddings[i:i + batch_size]
        batch_sparse = sparse_embeddings[i:i + batch_size]

        points = []
        for ch, vec, s_vec in zip(batch_chunks, batch_vectors, batch_sparse):
            # Векторы теперь словарь, т.к. их несколько (Dense по умолчанию + bm25)
            vector_dict = {
                "": vec.tolist() if hasattr(vec, "tolist") else list(vec), # Безымянный = Dense
                "bm25": s_vec                                               # Именованный = Sparse
            }
            
            points.append(
                models.PointStruct(
                    id=ch["chunk_id"],  # UUID чанка
                    vector=vector_dict,
                    # Метаданные чанка — эти поля возвращаются при поиске
                    payload={
                        "chunk_id": ch["chunk_id"],
                        "doc_id": ch["doc_id"],             # Имя исходного файла / ID статьи
                        "title": ch["title"],               # Заголовок документа
                        "url": ch["url"],                   # Ссылка-источник
                        "category": ch["category"],         # Категория (для фильтрации)
                        "doc_type": ch["doc_type"],         # Тип документа (instruction / legislation / faq)
                        "section_header": ch["section_header"],  # Заголовок раздела (breadcrumbs)
                        "step_number": ch.get("step_number"),   # Номер шага ("Шаг 1" и т.д.)
                        "images": ch.get("images", []),     # Локальные пути к скриншотам
                        "text": ch["text"]                  # Полный текст чанка с контекстом
                    }
                )
            )

        # Отправляем батч в Qdrant. wait=True — ждём подтверждения записи.
        client.upsert(
            collection_name=COLLECTION_NAME,
            wait=True,
            points=points
        )
